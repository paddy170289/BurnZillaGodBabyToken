# BurnZillaGodBaby (BZGB)

Deflationärer BEP-20 Token mit 1% Auto-Burn für jede Transaktion. Vollständig dezentral und ohne Owner.

## Eigenschaften
- ✅ 1% Auto-Burn auf jede Transaktion
- 🔥 50% Initial Burn (500.000.000 BZGB)
- 👥 5% Team & Marketing Wallet
- 🚀 45% Presale Wallet
- 📛 Ownership wurde nicht implementiert (kein Ownable)
